package fetch.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


// edit family tied to account
// add, edit, delete any entries/kids

public class Family extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_family);
    }
}
